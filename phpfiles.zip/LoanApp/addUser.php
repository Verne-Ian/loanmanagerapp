<?php

include "conn.php";


$first_name = $_POST["first_name"];
$last_name = $_POST["last_name"];
$phone = $_POST["phone_no"];
$email = $_POST["email"];
$local_add = $_POST["local_address"];
$uname = $_POST["uname"];
$pass = $_POST["pass"];


$sql = "INSERT INTO $table1(first_name, last_name, phone_no, email, local_address, username, pass) 
        VALUES('$first_name','$last_name','$phone','$email','$local_add','$uname','$pass')";
    
$result = $conn->query($sql);
echo "Done";
$conn->close();
return;


?>