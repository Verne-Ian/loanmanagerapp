<?php

include "conn.php";

$userId =$_POST['userId'];
$sql = "DELETE from Users where ID = $userId";

if($conn->query($sql) === TRUE){
	echo "Done";
}else{
	echo "Error";
}
$conn->close();

?>

