<?php

include "conn.php";

$userId = $_POST["userId"];
$first_name = $_POST["first_name"];
$last_name = $_POST["last_name"];
$phone = $_POST["phone_no"];
$email = $_POST["email"];
$local_add = $_POST["local_address"];
$ulevel = $_POST["ulevel"];

$sql = "UPDATE Users SET first_name = '".$first_name."', last_name = '".$last_name."', phone_no = '".$phone."', email = '".$email."', 
			local_address = '".$local_add."', ulevel = '".$ulevel."' WHERE ID ='".$userId."'";

    
if($conn->query($sql) === TRUE){
	echo "Done";
}
else{
	echo "Error";
}
$conn->close();

?>

