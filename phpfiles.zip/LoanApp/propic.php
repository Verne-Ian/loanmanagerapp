<?php

include "conn.php";

$image =$_FILE['proPic']['uname'];
$uname = $_POST['uname'];

$imagePath = 'propics/'.$image;

$tmp_name = $_FILE['proPic']['tmp_name'];

move_uploaded_file($imagePath, $tmp_name);

$sql = "UPDATE Users SET picture = '".$image."' WHERE username = '".$uname."'";

$conn->query($sql);


?>
