<?php

include "conn.php";
    
$user = $_POST['username'];
$pass = $_POST['password'];

$q = $conn->query(" SELECT * from Users where username ='".$user."' and pass = '".$pass."'  ");
$result = array();

while($fetchData = $q->fetch_assoc()){
	$result[] = $fetchData;
}
echo json_encode($result);

?>
