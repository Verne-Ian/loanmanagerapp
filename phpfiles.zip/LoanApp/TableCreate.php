<?php

include "conn.php";

$sql = "CREATE TABLE IF NOT EXISTS $table1(
	ID INT(2) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	first_name VARCHAR(25) NOT NULL,
	last_name VARCHAR(30) NOT NULL,
	phone_no INT(10) NOT NULL,
	email VARCHAR(20) NOT NULL,
	local_address VARCHAR(60) NOT NULL,
	username VARCHAR(15) NOT NULL UNIQUE,
	pass VARCHAR(30) NOT NULL,
	ulevel VARCHAR(6)
)";
if($conn->query($sql) === TRUE){
	//App feedback
	echo "Done";
}else if($conn->query($sql) === FALSE){
	echo "Error";
}
$conn->close();


?>

