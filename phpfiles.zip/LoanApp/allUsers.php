<?php

include "conn.php";

//$db_data = array();
//$sql = "SELECT * FROM Users";
    
//$result = $conn->query($sql);

$sql = $conn->query(" SELECT ID, first_name, last_name, phone_no, email, pass, ulevel, picture from Users");
$result = array();

while($fetchData = $sql->fetch_assoc()){
	$result[] = $fetchData;
}
echo json_encode($result);

    //save to the array
//if($row->num_rows > 0){
//	while($row = $result->fetch_assoc()){
//		$db_data [] = $row;
//	}
//	echo json_encode($db_data);
//}
//else
//{
//	echo "Error";
//}
$conn->close();

?>

